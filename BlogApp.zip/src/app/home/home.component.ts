import { Component, OnInit, OnDestroy } from '@angular/core';
import { BlogService } from './../blog.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})
export class HomeComponent implements OnInit, OnDestroy {
  homeMessage = 'I am in home +';

  public allBlogs;

  constructor(private _blogService: BlogService) {
    this.allBlogs = [];
  }

  ngOnInit(){
    // this.allBlogs = this._blogService.getAllBlogs();
    this._blogService.getBlodDetail(undefined).subscribe(

      data => {
          console.log(data["data"]);
          this.allBlogs = data["data"];
      },

      error => {
        console.log(error.errorMessage);
      }
    );

  }

  public getShortText(textValue:string, textLength:number):string{
    let returnVal:string = '';

    returnVal = textValue;

    if(textValue.length > textLength)
    {
      returnVal = textValue.substring(0,textLength) + '...';
    }

    return returnVal;
  }

  ngOnDestroy(){}
}