import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BlogService } from '../blog.service';

@Component({
  selector: 'app-view-blog',
  templateUrl: './viewBlog.component.html'
})
export class ViewBlogComponent implements OnInit {
  public blogId = undefined;

  public blogTitle;
  public blogDescription;
  public blogBodyHtml;
  public blogCategory;

  public isBlogLoaded;

  constructor(private _activateRoute: ActivatedRoute, private blogService: BlogService) {
    console.log('View-HTML called');

    this.isBlogLoaded = false;
  }

  ngOnInit() {
    this.blogId = this._activateRoute.snapshot.params.blogId;

    if (!this.blogId) return;

    this.blogService.getBlodDetail(this.blogId).subscribe(
      params => {

        let blogData = params['data'];

        // console.log(this.blogData);

        if (blogData) {
          this.isBlogLoaded = true;
        }

        if(this.isBlogLoaded)
        {
          this.blogTitle = blogData.title;
          this.blogDescription = blogData.description;
          this.blogBodyHtml = blogData.bodyHtml;
          this.blogCategory = blogData.category;
        }
      }
    );
  }

}