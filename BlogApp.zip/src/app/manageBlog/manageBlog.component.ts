import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BlogService } from './../blog.service';

@Component({
  selector: 'app-manage-blog',
  templateUrl: './manageBlog.component.html',
  styleUrls: ['./manageBlog.component.css']
})
export class ManageBlogComponent implements OnInit {
  createMessage = 'I am in ManageBlog';

  public mode = 'new';
  public blogId = undefined;

  constructor(private _activateRoute: ActivatedRoute, private _blogService: BlogService){
  }


  public blogTitle;
  public blogDescription;
  public blogBodyHtml;  
  public blogCategory;

  public possibleCategories = ["Comedy", "Technology", "Home-Science"];

  ngOnInit() { 
    this._activateRoute.queryParams.subscribe( 
      params => { 
        this.mode =  params['mode']; 
        this.blogId=params['blogId'];
      } 
    ) 
  }

  createBlog(){
    let blogData = {
      title: this.blogTitle,
      description: this.blogDescription,
      blogBody: this.blogBodyHtml,
      category: this.blogCategory
    } 

    this._blogService.manageBlog(this.blogId, blogData).subscribe(
      params =>{
        console.log(params.error);
        console.log(params.message);
        console.log(params.status);
      }

    )

  }
}