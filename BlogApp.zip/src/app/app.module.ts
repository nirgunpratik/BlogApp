import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { HomeComponent } from './home/home.component';
import { ManageBlogComponent } from './manageBlog/manageBlog.component';
import { ViewBlogComponent } from './viewBlog/viewBlog.component';
import { BlogService } from './blog.service';

import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes} from '@angular/router';

import { FormsModule } from '@angular/forms'


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ManageBlogComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule,
    RouterModule.forRoot([
      {path: 'home', component: HomeComponent},
      {path: 'manage', component: ManageBlogComponent},
      // {path: 'manage/', component: ManageBlogComponent},
      {path: 'view/:blogId', component: ViewBlogComponent},
      {path: '.',  redirectTo: 'home', pathMatch: 'full'}
    ])
  ],
  providers: [BlogService],
  bootstrap: [AppComponent]
})
export class AppModule { }
