import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { catchError } from 'rxjs/operators';
import { tap } from 'rxjs/operators';


// import { , catch } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class BlogService {

  public allBlogs;
  public currentBlog;

  private authToken = 'N2ZiM2RiODE3MjgzMjEwM2IwYjdhNjlmMWM2MWI0OWQ2NDBmMTRhYjFiNjFjYzE4Y2JiYTEwOGEzMzFiMDc4ZDZiYzAxMTZiNzRhYjUxNTcwMTkxYWZiNDFiZTM5NjFjNmQ0NzMxYTNjOGVkNzVlNTY5NmQyMjllMmY3NDY0OGI1OA==';

  private _baseUrl;

  constructor(private _http: HttpClient) {
    this._baseUrl = 'https://blogapp.edwisor.com/api/v1/blogs/';
  }

  // private handleError(err: HttpErrorResponse) {
  //   console.log(err.message);

  //   return Observable.throw(err.message);
  // }

  public getBlodDetail(blogId): any {
    let myResponse
    if (!blogId) {
      myResponse = this._http.get(this._baseUrl + 'all?authToken=' + this.authToken);
    }
    else {
      myResponse = this._http.get(this._baseUrl + 'view/' + blogId + '?authToken=' + this.authToken);
    }
    console.log(myResponse);
    return myResponse;
  }

  public manageBlog(blogId, data): any {
    let myResponse;
    if (blogId) {
      myResponse = this._http.post(this._baseUrl + 'create?authToken=' + this.authToken, data);
    }
    else {
      myResponse = this._http.post(this._baseUrl + 'create?authToken=' + this.authToken, data);
    }

    console.log(myResponse);
    
    return myResponse;
  }

  public getSingleBlog(blogId): any {

  }
}
